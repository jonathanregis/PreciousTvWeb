  
            <ul class="navigation">  
   <li class="active">
                    <a href="#" class="bldblue">Menu</a>
                    <div class="open"></div>
                    <ul>
                         <li><a href="menu.php">Edit/Delete</a></li>
                        						
                    </ul>
                </li>			
                <li><a href="#" class="blblue">Home</a>
				<div class="open"></div>
                    <ul>
                         <li><a href="slider_image.php">Slider Image</a></li>
                        <li class="active"><a href="widgets.php">Introduction Word</a></li>
                        <li class="active"><a href="view_daily_verse.php">Daily Verse</a></li>
<li class="active"><a href="home.php">Comming Programs</a></li>
<li class="active"><a href="tables_dynamic.html">Sidebar widget</a></li> 
                       
                    </ul></li>
                <li>
                    <a href="#" class="blyellow">About Us</a>
                    <div class="open"></div>
                    <ul>
                        <li><a href="view_daily_verse.php">View & Edit Verse</a></li>
                        
                       
                    </ul>
                </li>
                <li>
                    <a href="#" class="blgreen">Streaming Now</a>
                    <div class="open"></div>
                    <ul>
                       
                    </ul>
                </li>
                <li><a href="statistic.html" class="blred">Programs</a></li>                
             
                <li>
                    <a href="#" class="blpurple">Prayer&testimony</a>
                    <div class="open"></div>
                    <ul>
                       </ul>                    
                </li>
                <li>
                    <a href="#" class="blorange">Blog</a>
                    <div class="open"></div>
                    <ul>
                       </ul>
                </li><li>
                    <a href="#" class="blorange">Contact Us</a>
                    <div class="open"></div>
                    <ul>
                         </ul>
                </li>
            </ul>