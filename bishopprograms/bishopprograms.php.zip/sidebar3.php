

<div class="col-xs-12 col-md-4">
								
								<div class="volunteer-reward">
									<div class="video-section">
									<h3 class="col-title">Live Service</h3>
								<span class="liner "></span>
										<div class="fb-video" data-href="https://www.facebook.com/precioustelevision.tv/videos/1051013578291899/" data-width="500"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/precioustelevision.tv/videos/977049552354969/"><a href="https://www.facebook.com/precioustelevision.tv/videos/977049552354969/"></a><p></p>Posté par <a href="https://www.facebook.com/precioustelevision.tv/">Precious TV</a> sur samedi 2 janvier 2016</blockquote></div></div>
									</div>
								</div>
								<h3 class="col-title">For an Experience </h3>
								<span class="liner "></span>
								
								<div class="fb-video" data-href="https://www.facebook.com/facebook/videos/10153231379946729/" data-width="500">
     <div class="fb-video" data-href="https://www.facebook.com/precioustelevision.tv/videos/869718866421372/" data-width="500"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/precioustelevision.tv/videos/869718866421372/"><a href="https://www.facebook.com/precioustelevision.tv/videos/869718866421372/"></a><p></p>Posté par <a href="https://www.facebook.com/precioustelevision.tv/">Precious TV</a> sur jeudi 21 mai 2015</blockquote></div></div>
								
								
								
								
								<div class="fb-page" data-href="https://www.facebook.com/precioustelevision.tv?fref=ts" data-width="100%" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true" data-show-posts="false"></div>
						
						<h3 class="col-title">Latest Videos </h3>
								<span class="liner "></span>	
									
									
										
									
								<div class="fb-video" data-href="https://www.facebook.com/precioustelevision.tv/videos/672890886104172/?theater" data-width="500"><div class="fb-xfbml-parse-ignore">
										
										
										
										</div></div>
						<!--iframe src="http://www.instget.com/widget/?w=294370cbe63f8d7712f3c23e91438b21" allowtransparency="true" scrolling="no" style="border: none; overflow: hidden; width: 100%; height: 352px;" frameborder="0"></iframe></div>
						--></div></div>