<section class="latest-news ">
					<div class="container anim-section">
						<div class="row">
							<div class="col-xs-12">
								<header class="clearfix">
									<h2 style="color: #1C214B;">Bishop Agyinasare <strong>Programs</strong></h2>
								</header>

								<div class="article-list row">
									<div class="cols-xs-12 col-sm-4">
										

												
												<div class="embed-responsive embed-responsive-16by9">
													<div class="fb-video" data-href="https://www.facebook.com/precioustelevision.tv/videos/650955638297697/?theater" data-width="500"><div class="fb-xfbml-parse-ignore">
													</div></div>
													</div>

											
												<h2 style="color:#1C214B;font-size:18px">Time with  <strong>Bishop Charles</strong> <i class="fa fa-video-camera"></i>

30 Min</h2>
							<p style="color: #1C214B;">
													this is a special time where Bishop devotes 30 minutes to receiving and answering questions, issues, and people’s personal dilemmas concerning messages that he has preached on in the past.  <br/></p>

											
										</div>
									<div class="cols-xs-12 col-sm-4">
											<div class="embed-responsive embed-responsive-16by9">
													<div class="fb-video" data-href="https://www.facebook.com/precioustelevision.tv/videos/667770596616201/?theater" data-width="500"><div class="fb-xfbml-parse-ignore">
													</div></div>
													</div>

												
<h2 style="color:#1C214B;font-size:18px">Dividing <strong>the Word </strong> <i class="fa fa-video-camera"></i>

30 Min</h2>
								<p style="color: #1C214B;">
													this program shows full-length miracle meetings that Bishop did particularly in churches, usually in those where he was invited to minister. <br/><br/></p>

											</div>
									<div class="cols-xs-12 col-sm-4">
										<div class="embed-responsive embed-responsive-16by9">
										
										<div class="fb-video" data-href="https://www.facebook.com/precioustelevision.tv/videos/667776463282281/?theater" data-width="500"><div class="fb-xfbml-parse-ignore">
										</div></div></div>
										
									

												
												<h2 style="color:#1C214B;font-size:18px">Divine <strong>Encounter </strong><i class="fa fa-video-camera"></i>

 60 Min</h2>
							<p style="color: #1C214B;">
													This program shows full-length miracle meetings that Bishop did particularly in churches, usually in those where he was invited to minister.<br/><br/><br/></p>

											</div>

								</div>
							</div>
						</div>
					</div>
				</section>