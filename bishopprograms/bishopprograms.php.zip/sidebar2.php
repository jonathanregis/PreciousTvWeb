
<div class="col-xs-12 col-md-4">

<div class="row">
<div class="col-sm-4"  style="background-color:lavender;">
								
								<div class="volunteer-reward">
									<div class="video-section">
										<div class="fb-video" data-href="https://www.facebook.com/precioustelevision.tv/videos/1051013578291899/" data-width="100%">
										<div class="fb-xfbml-parse-ignore">
										
										
										
										</div></div>
									</div>
								</div>
								
				</div>
				</div>
				
								<h3 class="col-title">Join us on Facebook </h3>
								<span class="liner "></span>
								<div class="fb-page" data-href="https://www.facebook.com/starafricacollection/?fref=ts" data-width="100%" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true" data-show-posts="false"></div>
						<hr/>
						<h3 class="col-title">Latest Videos </h3>
								<span class="liner "></span>	
									
									
										
									
								<div class="fb-video" data-href="https://www.facebook.com/precioustelevision.tv/videos/672890886104172/?theater" data-width="500"><div class="fb-xfbml-parse-ignore">
										
										
										
										</div></div>
						<!--iframe src="http://www.instget.com/widget/?w=294370cbe63f8d7712f3c23e91438b21" allowtransparency="true" scrolling="no" style="border: none; overflow: hidden; width: 100%; height: 352px;" frameborder="0"></iframe></div>
						--></div></div>