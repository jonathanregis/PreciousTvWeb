<section class="latest-news news-section news-section3">
					<div class="container anim-section">
						<div class="row">
							<div class="col-xs-12 col-md-7">
								<div class="row">
									<header class="page-header section-header col-md-12 clearfix">
										<h2 style="color: #1B214A ;">Blog<strong> Article</strong></h2>
									</header>
									<?php  $while_query=mysql_query("select * from blog_article")or die(mysql_error());
                   while($row=mysql_fetch_array($while_query)){?><div class="items  col-xs-12 col-md-12">
										<div class="row">
										<div  id="fb-root" class="video-section">
										
										<script>
										(function(d, s, id) {  var js, fjs = d.getElementsByTagName(s)[0];  if (d.getElementById(id)) return;  js = d.createElement(s); js.id = id;  js.src = "//connect.facebook.net/fr_FR/sdk.js#xfbml=1&version=v2.3";  fjs.parentNode.insertBefore(js, fjs);}(document, 'script', 'facebook-jssdk'));</script><div class="fb-post" data-href="https://www.facebook.com/precioustelevision.tv/posts/981044798622111:0" data-width="500">
										<div class="fb-xfbml-parse-ignore">
										<blockquote cite="https://www.facebook.com/precioustelevision.tv/posts/981044798622111:0"><p>One Family. One Tragedy. God&#039;s Purpose.&quot;. David, a widower, is working himself to death. Late nights doing paperwork and...</p>Posté par <a href="https://www.facebook.com/precioustelevision.tv/">Precious TV</a> sur&nbsp;<a href="https://www.facebook.com/precioustelevision.tv/posts/981044798622111:0">dimanche 10 janvier 2016</a></blockquote></div></div>
										<div class="control">
											<h2></h2>
											<a href="#" class="play-btn"> <i class="fa fa-spinner fa-pulse"></i> </a>
										</div>
									</div>
									
									<div class="clear"> </div>
										 <div class="add-user-main-panel">
		 	
	 
	 


 </div>
											</div>
											
											
											<!---<div class="viwes">
					<div class="view-links">
						<ul>
							<li><h4>Share on:</h4></li>
							<li><a href="#"><img src="web/images/f1.png" title="facebook"></a></li>
							<li><a href="#"><img src="web/images/t1.png" title="Twitter"></a></li>
							<li><a href="#"><img src="web/images/s1.png" title="Google+"></a></li>
						</ul>
						<ul class="comment1">
							<li><a href="#">Comment(1)</a></li>
							<li><a href="#"><img src="web/images/re.png" title="report"><span>Report</span></a></li>
						</ul>
					</div>
					<div class="views-count">
						<p><span>2,500</span> Views</p>
					</div>
					
				</div>-->
			
									</div>
									<?php }; ?>
								</div>
							</div>
							<div style="width:31.667%" class="col-xs-12 col-md-5">
								
								<div class="volunteer-reward">
									<div class="video-section">
										<div class="fb-video" data-href="https://www.facebook.com/precioustelevision.tv/videos/650955638297697/?theater" data-width="500"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/precioustelevision.tv/videos/650955638297697/"><a href="https://www.facebook.com/precioustelevision.tv/videos/650955638297697/"></a><p></p>Posté par <a href="https://www.facebook.com/precioustelevision.tv/">Precious TV</a> sur vendredi 14 mars 2014</blockquote></div></div>
										<div class="control">
											<h2></h2>
											<a href="#" class="play-btn"> <i class="fa fa-play-circle-o"></i> </a>
										</div>
									</div>
								</div>
								<h3 class="col-title">Latest Articles </h3>
								<span class="liner "></span>
								<div class="Recent-Vodeos">
						<!--<iframe src="http://www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com%2Fprecioustelevision.tv/?fref=ts&width=600&colorscheme=light&show_faces=true&border_color&stream=true&header=true&height=435" scrolling="yes" frameborder="0" style="border:none; overflow:hidden; width:100%; height:430px; background: white; float:left; " allowtransparency="true"></iframe>
 
 -->


						<div class="video1">
							<img src="web/images/r1.jpg" title="video2">
							<span></span>
							<p>The Healing Presence – during this special time with Dr. Adamson,the healing presence of God will come to your room,  </p>
							<div class="clear"> </div>
						</div><div class="video1">
							<img src="web/images/r1.jpg" title="video2">
							<span></span>
							<p>The Healing Presence – during this special time with Dr. Adamson,the healing presence of God will come to your room,  </p>
							<div class="clear"> </div>
						</div>
						<div class="video1 video2">
							<img src="web/images/r2.jpg" title="video2">
							<span></span>
							<p>30-minute video highlighting some powerful and noteworthy testimonies of miracles that have taken place  </p>
							<div class="clear"> </div>
						</div>
						<div class="r-all">
							<a href="#">View All</a>
						</div>
					</div></div>
					</div>
				</section>